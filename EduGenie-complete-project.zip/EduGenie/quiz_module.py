from gemini_client import generate_json


QUIZ_SCHEMA = {
    "type": "object",
    "properties": {
        "questions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "question": {"type": "string"},
                    "options": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "correct_answer": {"type": "string"},
                    "explanation": {"type": "string"},
                },
                "required": [
                    "question", "options", "correct_answer", "explanation"
                ],
            },
        }
    },
    "required": ["questions"],
}


def generate_quiz(text: str, count: int = 3) -> dict:
    prompt = f"""Create {count} educational multiple-choice questions from the material below.

Material:
{text}

Requirements:
- exactly {count} questions
- exactly 4 options per question
- exactly one correct answer
- correct_answer must exactly match one option
- include a short explanation for the correct answer
- make distractors plausible
- return only data matching the requested JSON schema"""
    data = generate_json(prompt, QUIZ_SCHEMA)
    questions = data.get("questions", [])

    cleaned = []
    for item in questions[:count]:
        options = item.get("options", [])
        if len(options) != 4:
            continue
        if item.get("correct_answer") not in options:
            continue
        cleaned.append(item)

    if len(cleaned) != count:
        raise ValueError("The model did not return the requested number of valid quiz questions.")

    return {"questions": cleaned}
