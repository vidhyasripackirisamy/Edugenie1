from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
from typing import Optional, Literal

from explanation_module import explain_topic
from qna import answer_question
from quiz_module import generate_quiz
from summary_module import summarize_text
from learning_path import get_learning_recommendations

app = FastAPI(
    title="EduGenie",
    description="Google Gemini powered learning assistant",
    version="1.0.0",
)

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


class TextRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=20000)


class ExplainRequest(BaseModel):
    topic: str = Field(..., min_length=1, max_length=5000)


class QuizRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=20000)
    count: int = Field(default=3, ge=1, le=10)


class LearnRequest(BaseModel):
    topic: str = Field(..., min_length=1, max_length=1000)
    level: Literal["beginner", "intermediate", "advanced"] = "beginner"
    weeks: int = Field(default=6, ge=1, le=52)


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/health")
async def health():
    return {"status": "ok", "service": "EduGenie"}


@app.post("/qa")
async def qa(payload: TextRequest):
    try:
        return {"answer": answer_question(payload.text)}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.post("/explain")
async def explain(payload: ExplainRequest):
    try:
        return {"explanation": explain_topic(payload.topic)}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.post("/quiz")
async def quiz(payload: QuizRequest):
    try:
        return generate_quiz(payload.text, payload.count)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.post("/summarize")
async def summarize(payload: TextRequest):
    try:
        return {"summary": summarize_text(payload.text)}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.post("/learn/recommendations")
async def learn(payload: LearnRequest):
    try:
        return get_learning_recommendations(payload.topic, payload.level, payload.weeks)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))
