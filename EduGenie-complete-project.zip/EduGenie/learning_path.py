from gemini_client import generate_json


LEARNING_SCHEMA = {
    "type": "object",
    "properties": {
        "topic": {"type": "string"},
        "level": {"type": "string"},
        "duration": {"type": "string"},
        "steps": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "stage": {"type": "string"},
                    "weeks": {"type": "string"},
                    "concepts": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "practice": {"type": "string"},
                    "resources": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                },
                "required": ["stage", "weeks", "concepts", "practice", "resources"],
            },
        },
        "tips": {
            "type": "array",
            "items": {"type": "string"},
        },
    },
    "required": ["topic", "level", "duration", "steps", "tips"],
}


def get_learning_recommendations(topic: str, level: str = "beginner", weeks: int = 6) -> dict:
    prompt = f"""Create a personalized learning path for:
Topic: {topic}
Learner level: {level}
Duration: {weeks} weeks

Organize learning from the learner's current level toward advanced understanding.
Include concepts, practice activities, and useful types of resources such as official
documentation, books, videos, or practice sites. Do not invent exact URLs.
Return only JSON matching the schema."""
    return generate_json(prompt, LEARNING_SCHEMA, max_output_tokens=2200)
