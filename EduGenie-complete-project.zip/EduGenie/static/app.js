const task = document.getElementById("task");
const inputText = document.getElementById("inputText");
const runBtn = document.getElementById("runBtn");
const clearBtn = document.getElementById("clearBtn");
const resultCard = document.getElementById("resultCard");
const result = document.getElementById("result");
const copyBtn = document.getElementById("copyBtn");
const status = document.getElementById("status");
const levelRow = document.getElementById("levelRow");

task.addEventListener("change", () => {
  const isLearn = task.value === "learn";
  levelRow.classList.toggle("hidden", !isLearn);
  inputText.placeholder = {
    qa: "Example: What is the difference between RAM and ROM?",
    explain: "Example: Explain the Pythagorean theorem.",
    quiz: "Paste a passage or enter a topic for a 3-question MCQ quiz.",
    summarize: "Paste the educational passage you want to summarize.",
    learn: "Example: SQL"
  }[task.value];
});

clearBtn.addEventListener("click", () => {
  inputText.value = "";
  result.innerHTML = "";
  resultCard.classList.add("hidden");
});

copyBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(result.innerText);
  copyBtn.textContent = "Copied";
  setTimeout(() => copyBtn.textContent = "Copy", 1200);
});

async function checkHealth() {
  try {
    const r = await fetch("/health");
    if (!r.ok) throw new Error();
    status.textContent = "API online";
  } catch {
    status.textContent = "API offline";
  }
}
checkHealth();

runBtn.addEventListener("click", runTask);

async function runTask() {
  const text = inputText.value.trim();
  if (!text) {
    resultCard.classList.remove("hidden");
    result.innerHTML = '<div class="error">Please enter a topic, question, or passage.</div>';
    return;
  }

  runBtn.disabled = true;
  runBtn.textContent = "Generating…";
  resultCard.classList.remove("hidden");
  result.innerHTML = "<p>EduGenie is thinking…</p>";

  let endpoint, body;
  if (task.value === "qa") {
    endpoint = "/qa"; body = { text };
  } else if (task.value === "explain") {
    endpoint = "/explain"; body = { topic: text };
  } else if (task.value === "quiz") {
    endpoint = "/quiz"; body = { text, count: 3 };
  } else if (task.value === "summarize") {
    endpoint = "/summarize"; body = { text };
  } else {
    endpoint = "/learn/recommendations";
    body = {
      topic: text,
      level: document.getElementById("level").value,
      weeks: Number(document.getElementById("weeks").value)
    };
  }

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Request failed.");
    renderResult(task.value, data);
  } catch (err) {
    result.innerHTML = `<div class="error">${escapeHtml(err.message)}</div>`;
  } finally {
    runBtn.disabled = false;
    runBtn.textContent = "Generate";
  }
}

function renderResult(type, data) {
  if (type === "quiz") {
    result.innerHTML = data.questions.map((q, i) => `
      <div class="quiz-question">
        <h3>${i + 1}. ${escapeHtml(q.question)}</h3>
        ${q.options.map(o => `<label class="option"><input type="radio" name="q${i}" value="${escapeAttr(o)}"> ${escapeHtml(o)}</label>`).join("")}
        <button class="secondary small" onclick="showAnswer(${i})">Check answer</button>
        <div id="answer-${i}" class="result-content"></div>
        <div id="correct-${i}" hidden>${escapeHtml(q.correct_answer)}</div>
        <div id="why-${i}" hidden>${escapeHtml(q.explanation)}</div>
      </div>
    `).join("");
    return;
  }

  if (type === "learn") {
    result.innerHTML = `
      <h3>${escapeHtml(data.topic)}</h3>
      <p><strong>Level:</strong> ${escapeHtml(data.level)} &nbsp; <strong>Duration:</strong> ${escapeHtml(data.duration)}</p>
      ${data.steps.map(s => `
        <div class="stage">
          <h3>${escapeHtml(s.stage)}</h3>
          <p><strong>Weeks:</strong> ${escapeHtml(s.weeks)}</p>
          <p><strong>Concepts:</strong> ${s.concepts.map(escapeHtml).join(", ")}</p>
          <p><strong>Practice:</strong> ${escapeHtml(s.practice)}</p>
          <p><strong>Resources:</strong> ${s.resources.map(escapeHtml).join(" • ")}</p>
        </div>`).join("")}
      <h3>Study tips</h3>
      <ul>${data.tips.map(t => `<li>${escapeHtml(t)}</li>`).join("")}</ul>
    `;
    return;
  }

  const key = type === "qa" ? "answer" : type === "explain" ? "explanation" : "summary";
  result.innerHTML = `<div class="result-content">${escapeHtml(data[key] || "")}</div>`;
}

window.showAnswer = function(i) {
  const selected = document.querySelector(`input[name="q${i}"]:checked`);
  const box = document.getElementById(`answer-${i}`);
  const correct = document.getElementById(`correct-${i}`).textContent;
  const why = document.getElementById(`why-${i}`).textContent;
  if (!selected) {
    box.textContent = "Choose an option first.";
    return;
  }
  const ok = selected.value === correct;
  box.innerHTML = ok
    ? `<p class="correct">Correct!</p><p>${escapeHtml(why)}</p>`
    : `<p>Not quite. Correct answer: <strong>${escapeHtml(correct)}</strong></p><p>${escapeHtml(why)}</p>`;
};

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[c]));
}
function escapeAttr(value) { return escapeHtml(value); }
