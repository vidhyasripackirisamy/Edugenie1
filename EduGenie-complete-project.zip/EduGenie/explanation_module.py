import os
from gemini_client import generate_text

_LOCAL_PIPELINE = None


def _local_explain(topic: str) -> str:
    global _LOCAL_PIPELINE
    if _LOCAL_PIPELINE is None:
        from transformers import pipeline
        model_name = os.getenv("LOCAL_EXPLANATION_MODEL", "MBZUAI/LaMini-Flan-T5-783M")
        _LOCAL_PIPELINE = pipeline("text2text-generation", model=model_name)
    prompt = (
        "Explain the following educational topic for a beginner. "
        "Use simple language, short sections, and one example.\nTopic: " + topic
    )
    result = _LOCAL_PIPELINE(prompt, max_new_tokens=220, do_sample=False)
    return result[0]["generated_text"].strip()


def explain_topic(topic: str) -> str:
    # The documentation specifies LaMini-Flan-T5 for explanations.
    # LOCAL_EXPLANATION=true uses it; the default uses Gemini so first-run setup
    # stays lightweight. Both paths expose the same API.
    if os.getenv("LOCAL_EXPLANATION", "false").lower() == "true":
        try:
            return _local_explain(topic)
        except Exception:
            pass

    return generate_text(
        f"""You are EduGenie's concept-explanation tutor.
Explain this topic to a beginner: {topic}
Requirements:
- simple language
- 3 to 6 short sections
- include one practical/example analogy
- avoid unnecessary jargon
- finish with a one-sentence recap"""
    )
