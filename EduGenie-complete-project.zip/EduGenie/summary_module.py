from gemini_client import generate_text


def summarize_text(text: str) -> str:
    return generate_text(
        f"""Summarize the following educational passage for quick revision.

Passage:
{text}

Output:
- a short overview
- 4 to 8 key points
- retain important names, facts, formulas, or definitions
- remove repetition
- use simple student-friendly language"""
    )
