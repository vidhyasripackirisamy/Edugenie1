# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a FastAPI + HTML/CSS educational assistant based on the supplied project
documentation. It provides:

- Question & Answer
- Beginner-friendly concept explanation
- 3-question MCQ quiz generation
- Passage summarization
- Personalized learning paths

## Architecture

Browser → FastAPI → module → Gemini API

The supplied document specifies LaMini-Flan-T5 for explanation and Gemini for Q&A,
quiz, summary, and learning paths. This implementation keeps the LaMini model
optional (`LOCAL_EXPLANATION=true`) so the default installation remains lightweight.
Gemini is used as the fallback explanation engine.

## Requirements

- Python 3.10+
- Google Gemini API key
- Internet connection for Gemini API
- VS Code recommended

## Installation

### Windows PowerShell

```powershell
cd EduGenie
py -3.10 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Open `.env` and put your Gemini API key after `GEMINI_API_KEY=`.

### macOS/Linux

```bash
cd EduGenie
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
```

## Run

```bash
uvicorn main:app --reload
```

Open:

http://127.0.0.1:8000

Health check:

http://127.0.0.1:8000/health

## Optional local LaMini explanation

If you specifically want the local model described in the documentation:

```bash
pip install -r requirements-local.txt
```

Set in `.env`:

```text
LOCAL_EXPLANATION=true
```

The first explanation request may download the model and use significant RAM/storage.
If the local model cannot load, the application automatically falls back to Gemini.

## API endpoints

- `POST /qa`
- `POST /explain`
- `POST /quiz`
- `POST /summarize`
- `POST /learn/recommendations`

FastAPI interactive API documentation is available at:

http://127.0.0.1:8000/docs

## Testing

With the virtual environment active:

```bash
pytest -q
```

The tests validate the API health route and input validation without requiring a
live Gemini call.

## Troubleshooting

### "GEMINI_API_KEY is not configured"
Make sure `.env` exists in the project root and contains:

GEMINI_API_KEY=your_key_here

Restart Uvicorn after changing `.env`.

### Gemini API errors
Check that the key is valid, the model name in `GEMINI_MODEL` is available to your
account, and that you have network access.

### PowerShell blocks activation
You can run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Then activate `.venv` again.

## Project structure

EduGenie/
├── main.py
├── gemini_client.py
├── explanation_module.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── requirements-local.txt
├── .env.example
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── app.js
└── tests/
    └── test_api.py
