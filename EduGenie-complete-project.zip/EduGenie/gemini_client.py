import os
from functools import lru_cache
from google import genai
from google.genai import types


class GeminiError(RuntimeError):
    pass


@lru_cache(maxsize=1)
def get_client():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise GeminiError(
            "GEMINI_API_KEY is not configured. Create a .env file from .env.example "
            "and add your Google Gemini API key."
        )
    return genai.Client(api_key=api_key)


def generate_text(prompt: str, *, temperature: float = 0.4, max_output_tokens: int = 1200) -> str:
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    try:
        response = get_client().models.generate_content(
            model=model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=temperature,
                max_output_tokens=max_output_tokens,
            ),
        )
        text = response.text
        if not text:
            raise GeminiError("Gemini returned an empty response.")
        return text.strip()
    except Exception as exc:
        raise GeminiError(f"Gemini request failed: {exc}") from exc


def generate_json(prompt: str, schema: dict, *, temperature: float = 0.2, max_output_tokens: int = 1800) -> dict:
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    try:
        response = get_client().models.generate_content(
            model=model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=temperature,
                max_output_tokens=max_output_tokens,
                response_mime_type="application/json",
                response_schema=schema,
            ),
        )
        if not response.text:
            raise GeminiError("Gemini returned an empty JSON response.")
        import json
        return json.loads(response.text)
    except Exception as exc:
        raise GeminiError(f"Gemini structured-output request failed: {exc}") from exc
